?package(universal):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="universal" command="/usr/bin/universal"
