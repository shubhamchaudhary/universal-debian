# Defaults for universal initscript
# sourced by /etc/init.d/universal
# installed at /etc/default/universal by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
